import json
import base64
import gzip
import requests
import time
from datetime import datetime
import os

def lambda_handler(event, context):
    """
    Kinesis Data Streams에서 Loki로 로그 전송
    """
    loki_endpoint = os.environ['LOKI_ENDPOINT']
    loki_push_url = f"{loki_endpoint}/loki/api/v1/push"
    
    # Loki 스트림 데이터 준비
    streams = {}
    processed_count = 0
    error_count = 0
    
    print(f"Processing {len(event.get('Records', []))} records")
    
    for record in event.get('Records', []):
        try:
            # Kinesis 데이터 디코드
            payload = base64.b64decode(record['kinesis']['data'])
            
            # GZIP 압축 해제 시도
            try:
                payload = gzip.decompress(payload)
            except:
                pass  # 압축되지 않은 데이터
            
            # JSON 파싱
            log_data = json.loads(payload.decode('utf-8'))
            
            # 타임스탬프 생성 (나노초 단위)
            timestamp = int(time.time() * 1000000000)
            
            # 레이블 추출 및 생성
            labels = {
                'job': 'eatcloud-logs',
                'cluster': 'eatcloud',
                'stream': record['eventSourceARN'].split('/')[-1]  # stream name
            }
            
            # 로그 데이터에서 추가 레이블 추출
            if isinstance(log_data, dict):
                # Fluent Bit 로그 형식 처리
                if 'kubernetes' in log_data:
                    k8s_meta = log_data['kubernetes']
                    labels.update({
                        'namespace': k8s_meta.get('namespace_name', 'unknown'),
                        'pod': k8s_meta.get('pod_name', 'unknown'),
                        'container': k8s_meta.get('container_name', 'unknown')
                    })
                
                # 로그 메시지 추출
                log_message = log_data.get('log', log_data.get('message', json.dumps(log_data)))
            else:
                log_message = str(log_data)
            
            # 레이블을 키로 스트림 그룹화
            label_key = json.dumps(labels, sort_keys=True)
            
            if label_key not in streams:
                streams[label_key] = {
                    'stream': labels.copy(),
                    'values': []
                }
            
            streams[label_key]['values'].append([str(timestamp), log_message])
            processed_count += 1
            
        except Exception as e:
            print(f"Record processing error: {str(e)}")
            print(f"Record data: {record}")
            error_count += 1
            continue
    
    # Loki로 전송
    if streams:
        loki_payload = {
            'streams': list(streams.values())
        }
        
        try:
            headers = {
                'Content-Type': 'application/json',
                'X-Scope-OrgID': 'eatcloud'  # 멀티테넌시용 (선택사항)
            }
            
            response = requests.post(
                loki_push_url,
                json=loki_payload,
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 204:
                print(f"Successfully sent {processed_count} logs to Loki")
            else:
                print(f"Loki response error: {response.status_code} - {response.text}")
                raise Exception(f"Loki push failed: {response.status_code}")
                
        except requests.exceptions.RequestException as e:
            print(f"Request error: {str(e)}")
            raise
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'processed': processed_count,
            'errors': error_count,
            'streams_sent': len(streams)
        })
    }
